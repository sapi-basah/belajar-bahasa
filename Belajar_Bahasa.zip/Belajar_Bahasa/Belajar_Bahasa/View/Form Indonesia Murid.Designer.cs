﻿namespace Belajar_Bahasa.View
{
    partial class Form_Indonesia_Murid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            btnSoal_Indonesia = new Button();
            pictureBox3 = new PictureBox();
            cmbLatihan_Indonesia = new ComboBox();
            label3 = new Label();
            panel1 = new Panel();
            btnMateri_Indonesia = new Button();
            label2 = new Label();
            cmbMateri_Indonesia = new ComboBox();
            pictureBox2 = new PictureBox();
            label1 = new Label();
            btnKembali_Indonesia = new Button();
            pictureBox1 = new PictureBox();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.Controls.Add(btnSoal_Indonesia);
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(cmbLatihan_Indonesia);
            panel2.Controls.Add(label3);
            panel2.Location = new Point(51, 507);
            panel2.Name = "panel2";
            panel2.Size = new Size(1149, 100);
            panel2.TabIndex = 7;
            // 
            // btnSoal_Indonesia
            // 
            btnSoal_Indonesia.BackColor = Color.FromArgb(0, 132, 130);
            btnSoal_Indonesia.FlatAppearance.BorderSize = 0;
            btnSoal_Indonesia.FlatStyle = FlatStyle.Flat;
            btnSoal_Indonesia.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSoal_Indonesia.ForeColor = Color.White;
            btnSoal_Indonesia.Location = new Point(1020, 42);
            btnSoal_Indonesia.Name = "btnSoal_Indonesia";
            btnSoal_Indonesia.Size = new Size(110, 31);
            btnSoal_Indonesia.TabIndex = 3;
            btnSoal_Indonesia.Text = "BUKA";
            btnSoal_Indonesia.UseVisualStyleBackColor = false;
            btnSoal_Indonesia.Click += btnSoal_Indonesia_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.document_7538078;
            pictureBox3.Location = new Point(3, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(100, 94);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // cmbLatihan_Indonesia
            // 
            cmbLatihan_Indonesia.FormattingEnabled = true;
            cmbLatihan_Indonesia.Items.AddRange(new object[] { "Soal Bahasa Indonesia 1", "Soal Bahasa Indonesia 2", "Soal Bahasa Indonesia 3", "Soal Bahasa Indonesia 4", "Soal Bahasa Indonesia 5", "Soal Bahasa Indonesia 6", "Soal Bahasa Indonesia 7", "Soal Bahasa Indonesia 8", "Soal Bahasa Indonesia 9", "Soal Bahasa Indonesia 10" });
            cmbLatihan_Indonesia.Location = new Point(109, 50);
            cmbLatihan_Indonesia.Name = "cmbLatihan_Indonesia";
            cmbLatihan_Indonesia.Size = new Size(309, 23);
            cmbLatihan_Indonesia.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Schoolbook", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(109, 14);
            label3.Name = "label3";
            label3.Size = new Size(321, 23);
            label3.TabIndex = 1;
            label3.Text = "Latihan Soal Bahasa Indonesia";
            // 
            // panel1
            // 
            panel1.Controls.Add(btnMateri_Indonesia);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(cmbMateri_Indonesia);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(51, 401);
            panel1.Name = "panel1";
            panel1.Size = new Size(1149, 100);
            panel1.TabIndex = 8;
            // 
            // btnMateri_Indonesia
            // 
            btnMateri_Indonesia.BackColor = Color.FromArgb(0, 132, 130);
            btnMateri_Indonesia.FlatAppearance.BorderSize = 0;
            btnMateri_Indonesia.FlatStyle = FlatStyle.Flat;
            btnMateri_Indonesia.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMateri_Indonesia.ForeColor = Color.White;
            btnMateri_Indonesia.Location = new Point(1020, 44);
            btnMateri_Indonesia.Name = "btnMateri_Indonesia";
            btnMateri_Indonesia.Size = new Size(110, 31);
            btnMateri_Indonesia.TabIndex = 3;
            btnMateri_Indonesia.Text = "BUKA";
            btnMateri_Indonesia.UseVisualStyleBackColor = false;
            btnMateri_Indonesia.ClientSizeChanged += btnMateri_Indonesia_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Schoolbook", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(109, 12);
            label2.Name = "label2";
            label2.Size = new Size(260, 23);
            label2.TabIndex = 1;
            label2.Text = "Materi Bahasa Indonesia";
            // 
            // cmbMateri_Indonesia
            // 
            cmbMateri_Indonesia.FormattingEnabled = true;
            cmbMateri_Indonesia.Items.AddRange(new object[] { "Materi Indonesia 1", "Materi Indonesia 2", "Materi Indonesia 3", "Materi Indonesia 4", "Materi Indonesia 5", "Materi Indonesia 6", "Materi Indonesia 7", "Materi Indonesia 8", "Materi Indonesia 9", "Materi Indonesia 10" });
            cmbMateri_Indonesia.Location = new Point(109, 52);
            cmbMateri_Indonesia.Name = "cmbMateri_Indonesia";
            cmbMateri_Indonesia.Size = new Size(309, 23);
            cmbMateri_Indonesia.TabIndex = 2;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.clipboard_839860__1_;
            pictureBox2.Location = new Point(3, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(100, 94);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Schoolbook", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(71, 312);
            label1.Name = "label1";
            label1.Size = new Size(466, 55);
            label1.TabIndex = 6;
            label1.Text = "Bahasa Indonesia";
            // 
            // btnKembali_Indonesia
            // 
            btnKembali_Indonesia.BackColor = Color.FromArgb(0, 132, 130);
            btnKembali_Indonesia.FlatAppearance.BorderSize = 0;
            btnKembali_Indonesia.FlatStyle = FlatStyle.Flat;
            btnKembali_Indonesia.Font = new Font("Century Schoolbook", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnKembali_Indonesia.ForeColor = Color.White;
            btnKembali_Indonesia.Location = new Point(51, 39);
            btnKembali_Indonesia.Name = "btnKembali_Indonesia";
            btnKembali_Indonesia.Size = new Size(110, 31);
            btnKembali_Indonesia.TabIndex = 5;
            btnKembali_Indonesia.Text = "Kembali";
            btnKembali_Indonesia.UseVisualStyleBackColor = false;
            btnKembali_Indonesia.Click += btnKembali_Indonesia_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(51, 89);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1149, 306);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // Form_Indonesia_Murid
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1251, 658);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(label1);
            Controls.Add(btnKembali_Indonesia);
            Controls.Add(pictureBox1);
            Name = "Form_Indonesia_Murid";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form_Indonesia_Murid";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel2;
        private Button btnSoal_Indonesia;
        private PictureBox pictureBox3;
        private ComboBox cmbLatihan_Indonesia;
        private Label label3;
        private Panel panel1;
        private Button btnMateri_Indonesia;
        private Label label2;
        private ComboBox cmbMateri_Indonesia;
        private PictureBox pictureBox2;
        private Label label1;
        private Button btnKembali_Indonesia;
        private PictureBox pictureBox1;
    }
}