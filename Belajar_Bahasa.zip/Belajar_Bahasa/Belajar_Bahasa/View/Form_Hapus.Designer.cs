﻿namespace Belajar_Bahasa.View
{
    partial class Form_Hapus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            butbtnSimpan = new Button();
            cmb_Pertemuan = new ComboBox();
            txtlink = new TextBox();
            rb_Materi = new RadioButton();
            rb_soal = new RadioButton();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 78);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(65, 15);
            label3.TabIndex = 23;
            label3.Text = "Pertemuan";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 49);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(29, 15);
            label2.TabIndex = 22;
            label2.Text = "Link";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 18);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(51, 15);
            label1.TabIndex = 21;
            label1.Text = "Kategori";
            // 
            // butbtnSimpan
            // 
            butbtnSimpan.Location = new Point(341, 103);
            butbtnSimpan.Name = "butbtnSimpan";
            butbtnSimpan.Size = new Size(75, 23);
            butbtnSimpan.TabIndex = 20;
            butbtnSimpan.Text = "Simpan";
            butbtnSimpan.UseVisualStyleBackColor = true;
            // 
            // cmb_Pertemuan
            // 
            cmb_Pertemuan.FormattingEnabled = true;
            cmb_Pertemuan.Items.AddRange(new object[] { "Pertemuan 1", "Pertemuan 2", "Pertemuan 3", "Pertemuan 4", "Pertemuan 5", "Pertemuan 6", "Pertemuan 7", "Pertemuan 8", "Pertemuan 9", "Pertemuan 10" });
            cmb_Pertemuan.Location = new Point(81, 70);
            cmb_Pertemuan.Name = "cmb_Pertemuan";
            cmb_Pertemuan.Size = new Size(142, 23);
            cmb_Pertemuan.TabIndex = 19;
            // 
            // txtlink
            // 
            txtlink.Location = new Point(81, 41);
            txtlink.Name = "txtlink";
            txtlink.Size = new Size(335, 23);
            txtlink.TabIndex = 18;
            // 
            // rb_Materi
            // 
            rb_Materi.AutoSize = true;
            rb_Materi.Location = new Point(181, 16);
            rb_Materi.Name = "rb_Materi";
            rb_Materi.Size = new Size(59, 19);
            rb_Materi.TabIndex = 17;
            rb_Materi.TabStop = true;
            rb_Materi.Text = "Materi";
            rb_Materi.UseVisualStyleBackColor = true;
            // 
            // rb_soal
            // 
            rb_soal.AutoSize = true;
            rb_soal.Location = new Point(81, 16);
            rb_soal.Name = "rb_soal";
            rb_soal.Size = new Size(47, 19);
            rb_soal.TabIndex = 16;
            rb_soal.TabStop = true;
            rb_soal.Text = "Soal";
            rb_soal.UseVisualStyleBackColor = true;
            // 
            // Form_Hapus
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(429, 143);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(butbtnSimpan);
            Controls.Add(cmb_Pertemuan);
            Controls.Add(txtlink);
            Controls.Add(rb_Materi);
            Controls.Add(rb_soal);
            Name = "Form_Hapus";
            Text = "Form_Hapus";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private Label label2;
        private Label label1;
        private Button butbtnSimpan;
        private ComboBox cmb_Pertemuan;
        private TextBox txtlink;
        private RadioButton rb_Materi;
        private RadioButton rb_soal;
    }
}