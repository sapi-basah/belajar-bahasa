﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Belajar_Bahasa.View
{
    public partial class Form_Bahasa_Inggris : Form
    {
        public Form_Bahasa_Inggris()
        {
            InitializeComponent();
        }

        private void btnMateri_Inggris_Click(object sender, EventArgs e)
        {
            string selectedOption = cmbMateri_Inggris.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(selectedOption))
            {
                MessageBox.Show("Silakan pilih salah satu materi terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Dictionary<string, string> materiLinks = new Dictionary<string, string>
    {
        { "Materi 1", "https://drive.google.com/link1" },
        { "Materi 2", "https://drive.google.com/link2" },
        { "Materi 3", "https://drive.google.com/link3" },
        { "Materi 4", "https://drive.google.com/link4" },
        { "Materi 5", "https://drive.google.com/link5" },
        { "Materi 6", "https://drive.google.com/link6" },
        { "Materi 7", "https://drive.google.com/link7" },
        { "Materi 8", "https://drive.google.com/link8" },
        { "Materi 9", "https://drive.google.com/link9" },
        { "Materi 10", "https://drive.google.com/link10" }
    };

            if (materiLinks.ContainsKey(selectedOption))
            {
                System.Diagnostics.Process.Start(materiLinks[selectedOption]);
            }
            else
            {
                MessageBox.Show("Link untuk materi ini tidak tersedia.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSoal_Inggris_Click(object sender, EventArgs e)
        {
            string selectedOption = cmbLatihan_Inggris.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(selectedOption))
            {
                MessageBox.Show("Silakan pilih salah satu materi terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Dictionary<string, string> materiLinks = new Dictionary<string, string>
    {
        { "Materi 1", "https://drive.google.com/link1" },
        { "Materi 2", "https://drive.google.com/link2" },
        { "Materi 3", "https://drive.google.com/link3" },
        { "Materi 4", "https://drive.google.com/link4" },
        { "Materi 5", "https://drive.google.com/link5" },
        { "Materi 6", "https://drive.google.com/link6" },
        { "Materi 7", "https://drive.google.com/link7" },
        { "Materi 8", "https://drive.google.com/link8" },
        { "Materi 9", "https://drive.google.com/link9" },
        { "Materi 10", "https://drive.google.com/link10" }
    };

            if (materiLinks.ContainsKey(selectedOption))
            {
                System.Diagnostics.Process.Start(materiLinks[selectedOption]);
            }
            else
            {
                MessageBox.Show("Link untuk materi ini tidak tersedia.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void btnKembali_Inggris_Click(object sender, EventArgs e)
        {
            Form_Murid formMurid = new Form_Murid();
            formMurid.Show();

            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
