﻿namespace Belajar_Bahasa.View
{
    partial class Popup_Login_Murid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            txtPassword = new TextBox();
            txtEmail = new TextBox();
            btnLogin_Murid = new Button();
            label2 = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Login_Form;
            pictureBox1.Location = new Point(-196, -57);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(747, 570);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // txtPassword
            // 
            txtPassword.ForeColor = Color.FromArgb(0, 132, 130);
            txtPassword.Location = new Point(71, 182);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(272, 23);
            txtPassword.TabIndex = 7;
            // 
            // txtEmail
            // 
            txtEmail.ForeColor = Color.FromArgb(0, 132, 130);
            txtEmail.Location = new Point(71, 98);
            txtEmail.Multiline = true;
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(272, 23);
            txtEmail.TabIndex = 8;
            // 
            // btnLogin_Murid
            // 
            btnLogin_Murid.BackColor = Color.FromArgb(0, 132, 130);
            btnLogin_Murid.FlatAppearance.BorderSize = 0;
            btnLogin_Murid.FlatStyle = FlatStyle.Flat;
            btnLogin_Murid.Font = new Font("Century Schoolbook", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLogin_Murid.ForeColor = Color.White;
            btnLogin_Murid.Location = new Point(71, 241);
            btnLogin_Murid.Name = "btnLogin_Murid";
            btnLogin_Murid.Size = new Size(272, 29);
            btnLogin_Murid.TabIndex = 6;
            btnLogin_Murid.Text = "Login";
            btnLogin_Murid.UseVisualStyleBackColor = false;
            btnLogin_Murid.Click += btnLogin_Murid_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("Century Schoolbook", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(0, 132, 130);
            label2.Location = new Point(71, 160);
            label2.Name = "label2";
            label2.Size = new Size(85, 19);
            label2.TabIndex = 4;
            label2.Text = "Password";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.FromArgb(0, 132, 130);
            label3.Font = new Font("Century Schoolbook", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(71, 76);
            label3.Name = "label3";
            label3.Size = new Size(53, 19);
            label3.TabIndex = 5;
            label3.Text = "Email";
            // 
            // Popup_Login_Murid
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(447, 488);
            Controls.Add(txtPassword);
            Controls.Add(txtEmail);
            Controls.Add(btnLogin_Murid);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(pictureBox1);
            Name = "Popup_Login_Murid";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form_Login_Murid";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private TextBox txtPassword;
        private TextBox txtEmail;
        private Button btnLogin_Murid;
        private Label label2;
        private Label label3;
    }
}