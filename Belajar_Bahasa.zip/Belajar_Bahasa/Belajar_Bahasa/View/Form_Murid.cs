﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Belajar_Bahasa.View
{
    public partial class Form_Murid : Form
    {
        public Form_Murid()
        {

            InitializeComponent();
            Form_Login form_Login = new Form_Login();
            form_Login.Hide();
        }

        private void btnIng_Click(object sender, EventArgs e)
        {
            Form_Bahasa_Inggris formInggris = new Form_Bahasa_Inggris();
            formInggris.Show();
            this.Dispose();
        }

        private void btnInd_Click(object sender, EventArgs e)
        {
            Form_Indonesia_Murid formIndonesia = new Form_Indonesia_Murid();
            formIndonesia.Show();
            this.Dispose();
        }

        private void btnMan_Click(object sender, EventArgs e)
        {
            Form_Mandarin_Murid formMandarin = new Form_Mandarin_Murid();
            formMandarin.Show();
            this.Dispose();
        }
    }
}
