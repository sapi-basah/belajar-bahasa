﻿namespace Belajar_Bahasa.View
{
    partial class Form_Mandarin_Murid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnKembali_Mandarin = new Button();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            cmbMateri_Mandarin = new ComboBox();
            pictureBox2 = new PictureBox();
            panel1 = new Panel();
            btnMateri_Mandarin = new Button();
            btnSoal_Mandarin = new Button();
            panel2 = new Panel();
            pictureBox3 = new PictureBox();
            cmbLatihan_Mandarin = new ComboBox();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Schoolbook", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(71, 312);
            label1.Name = "label1";
            label1.Size = new Size(465, 55);
            label1.TabIndex = 11;
            label1.Text = "Bahasa Mandarin";
            // 
            // btnKembali_Mandarin
            // 
            btnKembali_Mandarin.BackColor = Color.FromArgb(0, 132, 130);
            btnKembali_Mandarin.FlatAppearance.BorderSize = 0;
            btnKembali_Mandarin.FlatStyle = FlatStyle.Flat;
            btnKembali_Mandarin.Font = new Font("Century Schoolbook", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnKembali_Mandarin.ForeColor = Color.White;
            btnKembali_Mandarin.Location = new Point(51, 39);
            btnKembali_Mandarin.Name = "btnKembali_Mandarin";
            btnKembali_Mandarin.Size = new Size(110, 31);
            btnKembali_Mandarin.TabIndex = 10;
            btnKembali_Mandarin.Text = "Kembali";
            btnKembali_Mandarin.UseVisualStyleBackColor = false;
            btnKembali_Mandarin.Click += btnKembali_Mandarin_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(51, 89);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1149, 306);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Schoolbook", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(109, 12);
            label2.Name = "label2";
            label2.Size = new Size(260, 23);
            label2.TabIndex = 1;
            label2.Text = "Materi Bahasa Mandarin";
            // 
            // cmbMateri_Mandarin
            // 
            cmbMateri_Mandarin.FormattingEnabled = true;
            cmbMateri_Mandarin.Items.AddRange(new object[] { "Materi Mandarin 1", "Materi Mandarin 2", "Materi Mandarin 3", "Materi Mandarin 4", "Materi Mandarin 5", "Materi Mandarin 6", "Materi Mandarin 7", "Materi Mandarin 8", "Materi Mandarin 9", "Materi Mandarin 10" });
            cmbMateri_Mandarin.Location = new Point(109, 52);
            cmbMateri_Mandarin.Name = "cmbMateri_Mandarin";
            cmbMateri_Mandarin.Size = new Size(309, 23);
            cmbMateri_Mandarin.TabIndex = 2;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.clipboard_839860__1_;
            pictureBox2.Location = new Point(3, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(100, 94);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(btnMateri_Mandarin);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(cmbMateri_Mandarin);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(51, 401);
            panel1.Name = "panel1";
            panel1.Size = new Size(1149, 100);
            panel1.TabIndex = 13;
            // 
            // btnMateri_Mandarin
            // 
            btnMateri_Mandarin.BackColor = Color.FromArgb(0, 132, 130);
            btnMateri_Mandarin.FlatAppearance.BorderSize = 0;
            btnMateri_Mandarin.FlatStyle = FlatStyle.Flat;
            btnMateri_Mandarin.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMateri_Mandarin.ForeColor = Color.White;
            btnMateri_Mandarin.Location = new Point(1020, 44);
            btnMateri_Mandarin.Name = "btnMateri_Mandarin";
            btnMateri_Mandarin.Size = new Size(110, 31);
            btnMateri_Mandarin.TabIndex = 3;
            btnMateri_Mandarin.Text = "BUKA";
            btnMateri_Mandarin.UseVisualStyleBackColor = false;
            btnMateri_Mandarin.Click += btnMateri_Mandarin_Click;
            // 
            // btnSoal_Mandarin
            // 
            btnSoal_Mandarin.BackColor = Color.FromArgb(0, 132, 130);
            btnSoal_Mandarin.FlatAppearance.BorderSize = 0;
            btnSoal_Mandarin.FlatStyle = FlatStyle.Flat;
            btnSoal_Mandarin.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSoal_Mandarin.ForeColor = Color.White;
            btnSoal_Mandarin.Location = new Point(1020, 42);
            btnSoal_Mandarin.Name = "btnSoal_Mandarin";
            btnSoal_Mandarin.Size = new Size(110, 31);
            btnSoal_Mandarin.TabIndex = 3;
            btnSoal_Mandarin.Text = "BUKA";
            btnSoal_Mandarin.UseVisualStyleBackColor = false;
            btnSoal_Mandarin.Click += btnSoal_Mandarin_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(btnSoal_Mandarin);
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(cmbLatihan_Mandarin);
            panel2.Controls.Add(label3);
            panel2.Location = new Point(51, 507);
            panel2.Name = "panel2";
            panel2.Size = new Size(1149, 100);
            panel2.TabIndex = 12;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.document_7538078;
            pictureBox3.Location = new Point(3, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(100, 94);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // cmbLatihan_Mandarin
            // 
            cmbLatihan_Mandarin.FormattingEnabled = true;
            cmbLatihan_Mandarin.Items.AddRange(new object[] { "Soal Bahasa Mandarin 1", "Soal Bahasa Mandarin 2", "Soal Bahasa Mandarin 3", "Soal Bahasa Mandarin 4", "Soal Bahasa Mandarin 5", "Soal Bahasa Mandarin 6", "Soal Bahasa Mandarin 7", "Soal Bahasa Mandarin 8", "Soal Bahasa Mandarin 9", "Soal Bahasa Mandarin 10" });
            cmbLatihan_Mandarin.Location = new Point(109, 50);
            cmbLatihan_Mandarin.Name = "cmbLatihan_Mandarin";
            cmbLatihan_Mandarin.Size = new Size(309, 23);
            cmbLatihan_Mandarin.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Schoolbook", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(109, 14);
            label3.Name = "label3";
            label3.Size = new Size(321, 23);
            label3.TabIndex = 1;
            label3.Text = "Latihan Soal Bahasa Mandarin";
            // 
            // Form_Mandarin_Murid
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1251, 658);
            Controls.Add(label1);
            Controls.Add(btnKembali_Mandarin);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(panel2);
            Name = "Form_Mandarin_Murid";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form_Mandarin_Murid";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnKembali_Mandarin;
        private PictureBox pictureBox1;
        private Label label2;
        private ComboBox cmbMateri_Mandarin;
        private PictureBox pictureBox2;
        private Panel panel1;
        private Button btnMateri_Mandarin;
        private Button btnSoal_Mandarin;
        private Panel panel2;
        private PictureBox pictureBox3;
        private ComboBox cmbLatihan_Mandarin;
        private Label label3;
    }
}