﻿namespace Belajar_Bahasa.View
{
    partial class Form_Indoneisa_Guru
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnEdit_Guru_Indonesia = new Button();
            btnKembali_Indo_Guru = new Button();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            btnMateri_Indonesia = new Button();
            label2 = new Label();
            cmbMateri_Indonesia_Guru = new ComboBox();
            pictureBox2 = new PictureBox();
            panel2 = new Panel();
            btnSoal_Indonesia = new Button();
            pictureBox3 = new PictureBox();
            cmbLatihan_Indonesia_Guru = new ComboBox();
            label3 = new Label();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // btnEdit_Guru_Indonesia
            // 
            btnEdit_Guru_Indonesia.BackColor = Color.FromArgb(0, 132, 130);
            btnEdit_Guru_Indonesia.FlatAppearance.BorderSize = 0;
            btnEdit_Guru_Indonesia.FlatStyle = FlatStyle.Flat;
            btnEdit_Guru_Indonesia.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEdit_Guru_Indonesia.ForeColor = Color.White;
            btnEdit_Guru_Indonesia.Location = new Point(51, 634);
            btnEdit_Guru_Indonesia.Name = "btnEdit_Guru_Indonesia";
            btnEdit_Guru_Indonesia.Size = new Size(152, 50);
            btnEdit_Guru_Indonesia.TabIndex = 24;
            btnEdit_Guru_Indonesia.Text = "Edit Materi";
            btnEdit_Guru_Indonesia.UseVisualStyleBackColor = false;
            // 
            // btnKembali_Indo_Guru
            // 
            btnKembali_Indo_Guru.BackColor = Color.FromArgb(0, 132, 130);
            btnKembali_Indo_Guru.FlatAppearance.BorderSize = 0;
            btnKembali_Indo_Guru.FlatStyle = FlatStyle.Flat;
            btnKembali_Indo_Guru.Font = new Font("Century Schoolbook", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnKembali_Indo_Guru.ForeColor = Color.White;
            btnKembali_Indo_Guru.Location = new Point(51, 39);
            btnKembali_Indo_Guru.Name = "btnKembali_Indo_Guru";
            btnKembali_Indo_Guru.Size = new Size(110, 31);
            btnKembali_Indo_Guru.TabIndex = 21;
            btnKembali_Indo_Guru.Text = "Kembali";
            btnKembali_Indo_Guru.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(51, 89);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1149, 306);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 20;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(btnMateri_Indonesia);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(cmbMateri_Indonesia_Guru);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(51, 401);
            panel1.Name = "panel1";
            panel1.Size = new Size(1149, 100);
            panel1.TabIndex = 23;
            // 
            // btnMateri_Indonesia
            // 
            btnMateri_Indonesia.BackColor = Color.FromArgb(0, 132, 130);
            btnMateri_Indonesia.FlatAppearance.BorderSize = 0;
            btnMateri_Indonesia.FlatStyle = FlatStyle.Flat;
            btnMateri_Indonesia.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMateri_Indonesia.ForeColor = Color.White;
            btnMateri_Indonesia.Location = new Point(1020, 44);
            btnMateri_Indonesia.Name = "btnMateri_Indonesia";
            btnMateri_Indonesia.Size = new Size(110, 31);
            btnMateri_Indonesia.TabIndex = 3;
            btnMateri_Indonesia.Text = "BUKA";
            btnMateri_Indonesia.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Schoolbook", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(109, 12);
            label2.Name = "label2";
            label2.Size = new Size(260, 23);
            label2.TabIndex = 1;
            label2.Text = "Materi Bahasa Indonesia\r\n";
            // 
            // cmbMateri_Indonesia_Guru
            // 
            cmbMateri_Indonesia_Guru.FormattingEnabled = true;
            cmbMateri_Indonesia_Guru.Location = new Point(109, 52);
            cmbMateri_Indonesia_Guru.Name = "cmbMateri_Indonesia_Guru";
            cmbMateri_Indonesia_Guru.Size = new Size(309, 23);
            cmbMateri_Indonesia_Guru.TabIndex = 2;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.clipboard_839860__1_;
            pictureBox2.Location = new Point(3, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(100, 94);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(btnSoal_Indonesia);
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(cmbLatihan_Indonesia_Guru);
            panel2.Controls.Add(label3);
            panel2.Location = new Point(51, 507);
            panel2.Name = "panel2";
            panel2.Size = new Size(1149, 100);
            panel2.TabIndex = 22;
            // 
            // btnSoal_Indonesia
            // 
            btnSoal_Indonesia.BackColor = Color.FromArgb(0, 132, 130);
            btnSoal_Indonesia.FlatAppearance.BorderSize = 0;
            btnSoal_Indonesia.FlatStyle = FlatStyle.Flat;
            btnSoal_Indonesia.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSoal_Indonesia.ForeColor = Color.White;
            btnSoal_Indonesia.Location = new Point(1020, 42);
            btnSoal_Indonesia.Name = "btnSoal_Indonesia";
            btnSoal_Indonesia.Size = new Size(110, 31);
            btnSoal_Indonesia.TabIndex = 3;
            btnSoal_Indonesia.Text = "BUKA";
            btnSoal_Indonesia.UseVisualStyleBackColor = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.document_7538078;
            pictureBox3.Location = new Point(3, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(100, 94);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // cmbLatihan_Indonesia_Guru
            // 
            cmbLatihan_Indonesia_Guru.FormattingEnabled = true;
            cmbLatihan_Indonesia_Guru.Location = new Point(109, 50);
            cmbLatihan_Indonesia_Guru.Name = "cmbLatihan_Indonesia_Guru";
            cmbLatihan_Indonesia_Guru.Size = new Size(309, 23);
            cmbLatihan_Indonesia_Guru.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Schoolbook", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(109, 14);
            label3.Name = "label3";
            label3.Size = new Size(321, 23);
            label3.TabIndex = 1;
            label3.Text = "Latihan Soal Bahasa Indonesia";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Schoolbook", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(71, 312);
            label1.Name = "label1";
            label1.Size = new Size(466, 55);
            label1.TabIndex = 27;
            label1.Text = "Bahasa Indonesia";
            // 
            // Form_Indoneisa_Guru
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1251, 709);
            Controls.Add(label1);
            Controls.Add(btnEdit_Guru_Indonesia);
            Controls.Add(btnKembali_Indo_Guru);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(panel2);
            Name = "Form_Indoneisa_Guru";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form_Indoneisa_Guru";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnEdit_Guru_Indonesia;
        private Button btnKembali_Indo_Guru;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Button btnMateri_Indonesia;
        private Label label2;
        private ComboBox cmbMateri_Indonesia_Guru;
        private PictureBox pictureBox2;
        private Panel panel2;
        private Button btnSoal_Indonesia;
        private PictureBox pictureBox3;
        private ComboBox cmbLatihan_Indonesia_Guru;
        private Label label3;
        private Label label1;
    }
}