﻿namespace Belajar_Bahasa.View
{
    partial class Form_Upload
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rb_soal = new RadioButton();
            rb_Materi = new RadioButton();
            txtlink = new TextBox();
            cmb_Pertemuan = new ComboBox();
            butbtnSimpan = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // rb_soal
            // 
            rb_soal.AutoSize = true;
            rb_soal.Location = new Point(82, 21);
            rb_soal.Name = "rb_soal";
            rb_soal.Size = new Size(47, 19);
            rb_soal.TabIndex = 0;
            rb_soal.TabStop = true;
            rb_soal.Text = "Soal";
            rb_soal.UseVisualStyleBackColor = true;
            // 
            // rb_Materi
            // 
            rb_Materi.AutoSize = true;
            rb_Materi.Location = new Point(182, 21);
            rb_Materi.Name = "rb_Materi";
            rb_Materi.Size = new Size(59, 19);
            rb_Materi.TabIndex = 1;
            rb_Materi.TabStop = true;
            rb_Materi.Text = "Materi";
            rb_Materi.UseVisualStyleBackColor = true;
            // 
            // txtlink
            // 
            txtlink.Location = new Point(82, 46);
            txtlink.Name = "txtlink";
            txtlink.Size = new Size(335, 23);
            txtlink.TabIndex = 2;
            // 
            // cmb_Pertemuan
            // 
            cmb_Pertemuan.FormattingEnabled = true;
            cmb_Pertemuan.Items.AddRange(new object[] { "Pertemuan 1", "Pertemuan 2", "Pertemuan 3", "Pertemuan 4", "Pertemuan 5", "Pertemuan 6", "Pertemuan 7", "Pertemuan 8", "Pertemuan 9", "Pertemuan 10" });
            cmb_Pertemuan.Location = new Point(82, 75);
            cmb_Pertemuan.Name = "cmb_Pertemuan";
            cmb_Pertemuan.Size = new Size(142, 23);
            cmb_Pertemuan.TabIndex = 3;
            // 
            // butbtnSimpan
            // 
            butbtnSimpan.Location = new Point(342, 108);
            butbtnSimpan.Name = "butbtnSimpan";
            butbtnSimpan.Size = new Size(75, 23);
            butbtnSimpan.TabIndex = 4;
            butbtnSimpan.Text = "Simpan";
            butbtnSimpan.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(13, 23);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(51, 15);
            label1.TabIndex = 5;
            label1.Text = "Kategori";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(13, 54);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(29, 15);
            label2.TabIndex = 6;
            label2.Text = "Link";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(13, 83);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(65, 15);
            label3.TabIndex = 7;
            label3.Text = "Pertemuan";
            // 
            // Form_Upload
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(429, 143);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(butbtnSimpan);
            Controls.Add(cmb_Pertemuan);
            Controls.Add(txtlink);
            Controls.Add(rb_Materi);
            Controls.Add(rb_soal);
            Name = "Form_Upload";
            Text = "Form_Upload";
            Load += Form_Upload_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RadioButton rb_soal;
        private RadioButton rb_Materi;
        private TextBox txtlink;
        private ComboBox cmb_Pertemuan;
        private Button butbtnSimpan;
        private Label label1;
        private Label label2;
        private Label label3;
    }
}