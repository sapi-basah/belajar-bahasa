﻿namespace Belajar_Bahasa.View
{
    partial class Popup_LoginGuru
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtEMAILGuru_Murid = new TextBox();
            txtPASSGuru_Murid = new TextBox();
            pictureBox1 = new PictureBox();
            btn_Login_Guru = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Font = new Font("Century Schoolbook", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(0, 132, 130);
            label1.Location = new Point(71, 76);
            label1.Name = "label1";
            label1.Size = new Size(53, 19);
            label1.TabIndex = 0;
            label1.Text = "Email";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("Century Schoolbook", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(0, 132, 130);
            label2.Location = new Point(71, 160);
            label2.Name = "label2";
            label2.Size = new Size(85, 19);
            label2.TabIndex = 0;
            label2.Text = "Password";
            // 
            // txtEMAILGuru_Murid
            // 
            txtEMAILGuru_Murid.ForeColor = Color.FromArgb(0, 132, 130);
            txtEMAILGuru_Murid.Location = new Point(71, 98);
            txtEMAILGuru_Murid.Name = "txtEMAILGuru_Murid";
            txtEMAILGuru_Murid.Size = new Size(272, 23);
            txtEMAILGuru_Murid.TabIndex = 2;
            // 
            // txtPASSGuru_Murid
            // 
            txtPASSGuru_Murid.ForeColor = Color.FromArgb(0, 132, 130);
            txtPASSGuru_Murid.Location = new Point(71, 182);
            txtPASSGuru_Murid.Name = "txtPASSGuru_Murid";
            txtPASSGuru_Murid.Size = new Size(272, 23);
            txtPASSGuru_Murid.TabIndex = 2;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Group_12;
            pictureBox1.Location = new Point(-144, -65);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(842, 642);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // btn_Login_Guru
            // 
            btn_Login_Guru.BackColor = Color.FromArgb(0, 132, 130);
            btn_Login_Guru.FlatAppearance.BorderSize = 0;
            btn_Login_Guru.FlatStyle = FlatStyle.Flat;
            btn_Login_Guru.Font = new Font("Century Schoolbook", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_Login_Guru.ForeColor = Color.White;
            btn_Login_Guru.Location = new Point(71, 267);
            btn_Login_Guru.Name = "btn_Login_Guru";
            btn_Login_Guru.Size = new Size(272, 29);
            btn_Login_Guru.TabIndex = 1;
            btn_Login_Guru.Text = "Login";
            btn_Login_Guru.UseVisualStyleBackColor = false;
            btn_Login_Guru.Click += btn_Login_Guru_Click;
            // 
            // Popup_LoginGuru
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(217, 217, 217);
            ClientSize = new Size(447, 488);
            Controls.Add(txtPASSGuru_Murid);
            Controls.Add(txtEMAILGuru_Murid);
            Controls.Add(btn_Login_Guru);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Name = "Popup_LoginGuru";
            Text = "Popup_LoginGuru";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtEMAILGuru_Murid;
        private TextBox txtPASSGuru_Murid;
        private PictureBox pictureBox1;
        private Button btn_Login_Guru;
    }
}