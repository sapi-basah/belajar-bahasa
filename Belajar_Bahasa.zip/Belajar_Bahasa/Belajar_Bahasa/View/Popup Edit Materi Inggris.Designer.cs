﻿namespace Belajar_Bahasa.View
{
    partial class Form_Guru_Up
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            cmbMateri_Soal_Inggris = new ComboBox();
            btnUpload_Inggris = new Button();
            brnEdit_Inggris = new Button();
            btnDelete_Inggris = new Button();
            listView2 = new ListView();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(22, 18);
            label1.Name = "label1";
            label1.Size = new Size(140, 19);
            label1.TabIndex = 0;
            label1.Text = "Silahkan Pilih :";
            // 
            // cmbMateri_Soal_Inggris
            // 
            cmbMateri_Soal_Inggris.FormattingEnabled = true;
            cmbMateri_Soal_Inggris.Items.AddRange(new object[] { "Inggris", "Mandarin", "Indonesia" });
            cmbMateri_Soal_Inggris.Location = new Point(22, 40);
            cmbMateri_Soal_Inggris.Name = "cmbMateri_Soal_Inggris";
            cmbMateri_Soal_Inggris.Size = new Size(290, 23);
            cmbMateri_Soal_Inggris.TabIndex = 3;
            // 
            // btnUpload_Inggris
            // 
            btnUpload_Inggris.BackColor = Color.FromArgb(0, 132, 130);
            btnUpload_Inggris.FlatAppearance.BorderSize = 0;
            btnUpload_Inggris.FlatStyle = FlatStyle.Flat;
            btnUpload_Inggris.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUpload_Inggris.ForeColor = Color.White;
            btnUpload_Inggris.Location = new Point(22, 616);
            btnUpload_Inggris.Name = "btnUpload_Inggris";
            btnUpload_Inggris.Size = new Size(83, 34);
            btnUpload_Inggris.TabIndex = 20;
            btnUpload_Inggris.Text = "Upload";
            btnUpload_Inggris.UseVisualStyleBackColor = false;
            btnUpload_Inggris.Click += btnUpload_Inggris_Click;
            // 
            // brnEdit_Inggris
            // 
            brnEdit_Inggris.BackColor = Color.FromArgb(0, 132, 130);
            brnEdit_Inggris.FlatAppearance.BorderSize = 0;
            brnEdit_Inggris.FlatStyle = FlatStyle.Flat;
            brnEdit_Inggris.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            brnEdit_Inggris.ForeColor = Color.White;
            brnEdit_Inggris.Location = new Point(111, 616);
            brnEdit_Inggris.Name = "brnEdit_Inggris";
            brnEdit_Inggris.Size = new Size(83, 34);
            brnEdit_Inggris.TabIndex = 20;
            brnEdit_Inggris.Text = "Edit";
            brnEdit_Inggris.UseVisualStyleBackColor = false;
            brnEdit_Inggris.Click += btnEdit_Inggris_Click;
            // 
            // btnDelete_Inggris
            // 
            btnDelete_Inggris.BackColor = Color.Red;
            btnDelete_Inggris.FlatAppearance.BorderSize = 0;
            btnDelete_Inggris.FlatStyle = FlatStyle.Flat;
            btnDelete_Inggris.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDelete_Inggris.ForeColor = Color.White;
            btnDelete_Inggris.Location = new Point(200, 616);
            btnDelete_Inggris.Name = "btnDelete_Inggris";
            btnDelete_Inggris.Size = new Size(83, 34);
            btnDelete_Inggris.TabIndex = 20;
            btnDelete_Inggris.Text = "Delete";
            btnDelete_Inggris.UseVisualStyleBackColor = false;
            btnDelete_Inggris.Click += btnDelete_Inggris_Click;
            // 
            // listView2
            // 
            listView2.Location = new Point(22, 69);
            listView2.Name = "listView2";
            listView2.Size = new Size(688, 541);
            listView2.TabIndex = 21;
            listView2.UseCompatibleStateImageBehavior = false;
            // 
            // Form_Guru_Up
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(735, 682);
            Controls.Add(listView2);
            Controls.Add(btnDelete_Inggris);
            Controls.Add(brnEdit_Inggris);
            Controls.Add(btnUpload_Inggris);
            Controls.Add(cmbMateri_Soal_Inggris);
            Controls.Add(label1);
            Name = "Form_Guru_Up";
            Text = "Form_Guru";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ListView listView1;
        private ComboBox cmbMateri_Soal_Inggris;
        private Button btnUpload_Inggris;
        private Button brnEdit_Inggris;
        private Button btnDelete_Inggris;
        private ListView listView2;
    }
}