﻿namespace Belajar_Bahasa.View
{
    partial class Form_Murid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            btning = new Button();
            btnMateri_Inggris = new Button();
            label2 = new Label();
            pictureBox2 = new PictureBox();
            label1 = new Label();
            panel2 = new Panel();
            btnind = new Button();
            button3 = new Button();
            label3 = new Label();
            pictureBox3 = new PictureBox();
            panel3 = new Panel();
            btnman = new Button();
            button5 = new Button();
            label4 = new Label();
            pictureBox4 = new PictureBox();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(217, 217, 217);
            pictureBox1.Image = Properties.Resources.dwdw;
            pictureBox1.Location = new Point(-5, 1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(922, 656);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(btning);
            panel1.Controls.Add(btnMateri_Inggris);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(12, 190);
            panel1.Name = "panel1";
            panel1.Size = new Size(410, 134);
            panel1.TabIndex = 5;
            // 
            // btning
            // 
            btning.BackColor = Color.FromArgb(0, 132, 130);
            btning.FlatAppearance.BorderSize = 0;
            btning.FlatStyle = FlatStyle.Flat;
            btning.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btning.ForeColor = Color.White;
            btning.Location = new Point(149, 52);
            btning.Name = "btning";
            btning.Size = new Size(141, 61);
            btning.TabIndex = 4;
            btning.Text = "BUKA";
            btning.UseVisualStyleBackColor = false;
            btning.Click += btnIng_Click;
            // 
            // btnMateri_Inggris
            // 
            btnMateri_Inggris.BackColor = Color.FromArgb(0, 132, 130);
            btnMateri_Inggris.FlatAppearance.BorderSize = 0;
            btnMateri_Inggris.FlatStyle = FlatStyle.Flat;
            btnMateri_Inggris.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMateri_Inggris.ForeColor = Color.White;
            btnMateri_Inggris.Location = new Point(1020, 44);
            btnMateri_Inggris.Name = "btnMateri_Inggris";
            btnMateri_Inggris.Size = new Size(110, 31);
            btnMateri_Inggris.TabIndex = 3;
            btnMateri_Inggris.Text = "BUKA";
            btnMateri_Inggris.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Schoolbook", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(124, 12);
            label2.Name = "label2";
            label2.Size = new Size(161, 23);
            label2.TabIndex = 1;
            label2.Text = "Bahasa Inggris";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.clipboard_839860__1_;
            pictureBox2.Location = new Point(3, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(115, 128);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(0, 132, 130);
            label1.Font = new Font("Century Schoolbook", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(15, 50);
            label1.Name = "label1";
            label1.Size = new Size(259, 55);
            label1.TabIndex = 4;
            label1.Text = "HALOO!!!";
            // 
            // panel2
            // 
            panel2.Controls.Add(btnind);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(pictureBox3);
            panel2.Location = new Point(12, 341);
            panel2.Name = "panel2";
            panel2.Size = new Size(410, 134);
            panel2.TabIndex = 5;
            // 
            // btnind
            // 
            btnind.BackColor = Color.FromArgb(0, 132, 130);
            btnind.FlatAppearance.BorderSize = 0;
            btnind.FlatStyle = FlatStyle.Flat;
            btnind.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnind.ForeColor = Color.White;
            btnind.Location = new Point(149, 52);
            btnind.Name = "btnind";
            btnind.Size = new Size(141, 61);
            btnind.TabIndex = 4;
            btnind.Text = "BUKA";
            btnind.UseVisualStyleBackColor = false;
            btnind.Click += btnInd_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(0, 132, 130);
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.White;
            button3.Location = new Point(1020, 44);
            button3.Name = "button3";
            button3.Size = new Size(110, 31);
            button3.TabIndex = 3;
            button3.Text = "BUKA";
            button3.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Schoolbook", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(124, 12);
            label3.Name = "label3";
            label3.Size = new Size(188, 23);
            label3.TabIndex = 1;
            label3.Text = "Bahasa Indonesia";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.clipboard_839860__1_;
            pictureBox3.Location = new Point(3, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(115, 128);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // panel3
            // 
            panel3.Controls.Add(btnman);
            panel3.Controls.Add(button5);
            panel3.Controls.Add(label4);
            panel3.Controls.Add(pictureBox4);
            panel3.Location = new Point(12, 491);
            panel3.Name = "panel3";
            panel3.Size = new Size(410, 134);
            panel3.TabIndex = 5;
            // 
            // btnman
            // 
            btnman.BackColor = Color.FromArgb(0, 132, 130);
            btnman.FlatAppearance.BorderSize = 0;
            btnman.FlatStyle = FlatStyle.Flat;
            btnman.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnman.ForeColor = Color.White;
            btnman.Location = new Point(149, 52);
            btnman.Name = "btnman";
            btnman.Size = new Size(141, 61);
            btnman.TabIndex = 4;
            btnman.Text = "BUKA";
            btnman.UseVisualStyleBackColor = false;
            btnman.Click += btnMan_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(0, 132, 130);
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.White;
            button5.Location = new Point(1020, 44);
            button5.Name = "button5";
            button5.Size = new Size(110, 31);
            button5.TabIndex = 3;
            button5.Text = "BUKA";
            button5.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century Schoolbook", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(124, 12);
            label4.Name = "label4";
            label4.Size = new Size(193, 23);
            label4.TabIndex = 1;
            label4.Text = "Bahasa Mandarin ";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.clipboard_839860__1_;
            pictureBox4.Location = new Point(3, 3);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(115, 128);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 0;
            pictureBox4.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.FromArgb(0, 132, 130);
            label6.Font = new Font("Century Schoolbook", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(15, 133);
            label6.Name = "label6";
            label6.Size = new Size(383, 32);
            label6.TabIndex = 4;
            label6.Text = "Mau belajar apa hari ini ?";
            // 
            // Form_Murid
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(916, 658);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(label6);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Name = "Form_Murid";
            Text = "Form_Murid";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Panel panel1;
        private Button btnMateri_Inggris;
        private Label label2;
        private PictureBox pictureBox2;
        private Label label1;
        private Button btning;
        private Panel panel2;
        private Button btnind;
        private Button button3;
        private Label label3;
        private PictureBox pictureBox3;
        private Panel panel3;
        private Button btnman;
        private Button button5;
        private Label label4;
        private PictureBox pictureBox4;
        private Label label6;
    }
}