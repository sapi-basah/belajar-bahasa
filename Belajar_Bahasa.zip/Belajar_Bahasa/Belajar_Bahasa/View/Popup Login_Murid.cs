﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Belajar_Bahasa.View
{
    public partial class Popup_Login_Murid : Form
    {
        public Popup_Login_Murid()
        {
            InitializeComponent();
        }

        private void btnLogin_Murid_Click(object sender, EventArgs e)
        {
            string validEmail = "ui12345@email";
            string validPassword = "12345";
            
            string inputEmail = txtEmail.Text;
            string inputPassword = txtPassword.Text;

            if (inputEmail == validEmail && inputPassword == validPassword)
            {
                Form_Login form_Login = new();
                form_Login.Hide();
                Form_Murid formMurid = new Form_Murid();
                formMurid.Show();

                this.Hide();
            }
            else
            {
                MessageBox.Show("Email atau password salah. Silakan coba lagi!",
                                "Login Gagal",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }
    }
}
