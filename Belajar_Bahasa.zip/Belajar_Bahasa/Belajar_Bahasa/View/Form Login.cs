﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Belajar_Bahasa.View
{
    public partial class Form_Login : Form
    {
        public Form_Login()
        {
            InitializeComponent();
        }

        private void LoginGuru_Click(object sender, EventArgs e)
        {

            Popup_LoginGuru loginGuru = new Popup_LoginGuru();
            loginGuru.ShowDialog();
        }

        
        private void LoginMurid_Click(object sender, EventArgs e)
        {
            Popup_Login_Murid loginMurid = new Popup_Login_Murid();
            loginMurid.ShowDialog();
        }

    }
}
