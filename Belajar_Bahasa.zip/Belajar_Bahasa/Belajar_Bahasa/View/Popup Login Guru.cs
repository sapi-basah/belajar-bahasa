﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Belajar_Bahasa.View
{
    public partial class Popup_LoginGuru : Form
    {
        public Popup_LoginGuru()
        {
            InitializeComponent();
        }
        private void btn_Login_Guru_Click(object sender, EventArgs e)
        {
            string emailGuru = "guru123@email.com"; 
            string passwordGuru = "12345"; 

            if (txtEMAILGuru_Murid.Text == emailGuru && txtPASSGuru_Murid.Text == passwordGuru)
            {
                
                Form_Guru_Up formGuru = new Form_Guru_Up();
                formGuru.Show();

                this.Hide(); 
            }
            else
            {
                MessageBox.Show("Email atau Password salah!", "Login Gagal", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
