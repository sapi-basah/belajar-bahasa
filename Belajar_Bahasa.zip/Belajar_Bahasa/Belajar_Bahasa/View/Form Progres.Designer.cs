﻿namespace Belajar_Bahasa.View
{
    partial class Form_Progres
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            pgbEnglish = new ProgressBar();
            panel1 = new Panel();
            label1 = new Label();
            panel2 = new Panel();
            label4 = new Label();
            progressBar1 = new ProgressBar();
            panel3 = new Panel();
            label6 = new Label();
            progressBar2 = new ProgressBar();
            btnKembali_Progres = new Button();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Login_Form;
            pictureBox1.Location = new Point(-14, -87);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1014, 852);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pgbEnglish
            // 
            pgbEnglish.Location = new Point(141, 50);
            pgbEnglish.Name = "pgbEnglish";
            pgbEnglish.Size = new Size(561, 12);
            pgbEnglish.TabIndex = 1;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pgbEnglish);
            panel1.Location = new Point(109, 203);
            panel1.Name = "panel1";
            panel1.Size = new Size(761, 100);
            panel1.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Schoolbook", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(22, 32);
            label1.Name = "label1";
            label1.Size = new Size(107, 30);
            label1.TabIndex = 2;
            label1.Text = "English";
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(label4);
            panel2.Controls.Add(progressBar1);
            panel2.Location = new Point(109, 325);
            panel2.Name = "panel2";
            panel2.Size = new Size(761, 100);
            panel2.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century Schoolbook", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(22, 32);
            label4.Name = "label4";
            label4.Size = new Size(137, 30);
            label4.TabIndex = 2;
            label4.Text = "Indonesia";
            label4.Click += label4_Click;
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(141, 50);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(561, 12);
            progressBar1.TabIndex = 1;
            // 
            // panel3
            // 
            panel3.BackColor = Color.White;
            panel3.Controls.Add(label6);
            panel3.Controls.Add(progressBar2);
            panel3.Location = new Point(109, 445);
            panel3.Name = "panel3";
            panel3.Size = new Size(761, 100);
            panel3.TabIndex = 2;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Schoolbook", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(22, 32);
            label6.Name = "label6";
            label6.Size = new Size(136, 30);
            label6.TabIndex = 2;
            label6.Text = "Mandarin";
            // 
            // progressBar2
            // 
            progressBar2.Location = new Point(141, 50);
            progressBar2.Name = "progressBar2";
            progressBar2.Size = new Size(561, 12);
            progressBar2.TabIndex = 1;
            // 
            // btnKembali_Progres
            // 
            btnKembali_Progres.BackColor = Color.FromArgb(0, 132, 130);
            btnKembali_Progres.FlatAppearance.BorderSize = 0;
            btnKembali_Progres.FlatStyle = FlatStyle.Flat;
            btnKembali_Progres.Font = new Font("Century Schoolbook", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnKembali_Progres.ForeColor = Color.White;
            btnKembali_Progres.Location = new Point(166, 123);
            btnKembali_Progres.Name = "btnKembali_Progres";
            btnKembali_Progres.Size = new Size(110, 31);
            btnKembali_Progres.TabIndex = 3;
            btnKembali_Progres.Text = "Kembali";
            btnKembali_Progres.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(0, 132, 130);
            label2.Font = new Font("Century Schoolbook", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(304, 120);
            label2.Name = "label2";
            label2.Size = new Size(335, 34);
            label2.TabIndex = 2;
            label2.Text = "PROGRES BELAJAR";
            // 
            // Form_Progres
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(984, 661);
            Controls.Add(label2);
            Controls.Add(btnKembali_Progres);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(pictureBox1);
            Name = "Form_Progres";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form_Progres";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private ProgressBar pgbEnglish;
        private Panel panel1;
        private Label label1;
        private Panel panel2;
        private Label label4;
        private ProgressBar progressBar1;
        private Panel panel3;
        private Label label6;
        private ProgressBar progressBar2;
        private Button btnKembali_Progres;
        private Label label2;
    }
}