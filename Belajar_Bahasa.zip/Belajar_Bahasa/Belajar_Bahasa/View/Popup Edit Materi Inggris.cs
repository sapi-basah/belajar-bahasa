﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Belajar_Bahasa.View
{
    public partial class Form_Guru_Up : Form
    {
        public Form_Guru_Up()
               {
            InitializeComponent();

            btnUpload_Inggris.Enabled = false;
            brnEdit_Inggris.Enabled = false;
            btnDelete_Inggris.Enabled = false;

            cmbMateri_Soal_Inggris.SelectedIndexChanged += cmbBahasa_SelectedIndexChanged;
        }

        private void cmbBahasa_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMateri_Soal_Inggris.SelectedItem != null && cmbMateri_Soal_Inggris.SelectedItem.ToString() != "")
            {
                btnUpload_Inggris.Enabled = true;
                brnEdit_Inggris.Enabled = true;
                btnDelete_Inggris.Enabled = true;
            }
            else
            {
                btnUpload_Inggris.Enabled = false;
                brnEdit_Inggris.Enabled = false;
                btnDelete_Inggris.Enabled = false;
            }
        }

        private void btnUpload_Inggris_Click(object sender, EventArgs e)
        {
            Form_Upload uploadForm = new Form_Upload();
            uploadForm.ShowDialog();
        }

        private void btnEdit_Inggris_Click(object sender, EventArgs e)
        {
            Form_Edit editForm = new Form_Edit();
            editForm.ShowDialog();
        }

        private void btnDelete_Inggris_Click(object sender, EventArgs e)
        {
            Form_Hapus deleteForm = new Form_Hapus();
            deleteForm.ShowDialog();
        }
    }
}
