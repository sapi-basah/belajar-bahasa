﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Belajar_Bahasa.View
{
    public partial class Form_Indonesia_Guru : Form
    {
        public Form_Indonesia_Guru()
        {
            InitializeComponent();
        }
    }
}
