﻿namespace Belajar_Bahasa.View
{
    partial class Form_Inggris_Guru
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnEdit_Guru_Inggris = new Button();
            btnKembali_Inggris_Guru = new Button();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            btnMateri_Inggris = new Button();
            label2 = new Label();
            cmbMateri_Inggris_Guru = new ComboBox();
            pictureBox2 = new PictureBox();
            panel2 = new Panel();
            btnSoal_Inggris = new Button();
            pictureBox3 = new PictureBox();
            cmbLatihan_Inggris_Guru = new ComboBox();
            label3 = new Label();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // btnEdit_Guru_Inggris
            // 
            btnEdit_Guru_Inggris.BackColor = Color.FromArgb(0, 132, 130);
            btnEdit_Guru_Inggris.FlatAppearance.BorderSize = 0;
            btnEdit_Guru_Inggris.FlatStyle = FlatStyle.Flat;
            btnEdit_Guru_Inggris.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEdit_Guru_Inggris.ForeColor = Color.White;
            btnEdit_Guru_Inggris.Location = new Point(51, 634);
            btnEdit_Guru_Inggris.Name = "btnEdit_Guru_Inggris";
            btnEdit_Guru_Inggris.Size = new Size(152, 50);
            btnEdit_Guru_Inggris.TabIndex = 31;
            btnEdit_Guru_Inggris.Text = "Edit Materi";
            btnEdit_Guru_Inggris.UseVisualStyleBackColor = false;
            // 
            // btnKembali_Inggris_Guru
            // 
            btnKembali_Inggris_Guru.BackColor = Color.FromArgb(0, 132, 130);
            btnKembali_Inggris_Guru.FlatAppearance.BorderSize = 0;
            btnKembali_Inggris_Guru.FlatStyle = FlatStyle.Flat;
            btnKembali_Inggris_Guru.Font = new Font("Century Schoolbook", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnKembali_Inggris_Guru.ForeColor = Color.White;
            btnKembali_Inggris_Guru.Location = new Point(51, 39);
            btnKembali_Inggris_Guru.Name = "btnKembali_Inggris_Guru";
            btnKembali_Inggris_Guru.Size = new Size(110, 31);
            btnKembali_Inggris_Guru.TabIndex = 28;
            btnKembali_Inggris_Guru.Text = "Kembali";
            btnKembali_Inggris_Guru.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(51, 89);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1149, 306);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 27;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(btnMateri_Inggris);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(cmbMateri_Inggris_Guru);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(51, 401);
            panel1.Name = "panel1";
            panel1.Size = new Size(1149, 100);
            panel1.TabIndex = 30;
            // 
            // btnMateri_Inggris
            // 
            btnMateri_Inggris.BackColor = Color.FromArgb(0, 132, 130);
            btnMateri_Inggris.FlatAppearance.BorderSize = 0;
            btnMateri_Inggris.FlatStyle = FlatStyle.Flat;
            btnMateri_Inggris.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMateri_Inggris.ForeColor = Color.White;
            btnMateri_Inggris.Location = new Point(1020, 44);
            btnMateri_Inggris.Name = "btnMateri_Inggris";
            btnMateri_Inggris.Size = new Size(110, 31);
            btnMateri_Inggris.TabIndex = 3;
            btnMateri_Inggris.Text = "BUKA";
            btnMateri_Inggris.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Schoolbook", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(109, 12);
            label2.Name = "label2";
            label2.Size = new Size(233, 23);
            label2.TabIndex = 1;
            label2.Text = "Materi Bahasa Inggris";
            // 
            // cmbMateri_Inggris_Guru
            // 
            cmbMateri_Inggris_Guru.FormattingEnabled = true;
            cmbMateri_Inggris_Guru.Location = new Point(109, 52);
            cmbMateri_Inggris_Guru.Name = "cmbMateri_Inggris_Guru";
            cmbMateri_Inggris_Guru.Size = new Size(309, 23);
            cmbMateri_Inggris_Guru.TabIndex = 2;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.clipboard_839860__1_;
            pictureBox2.Location = new Point(3, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(100, 94);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(btnSoal_Inggris);
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(cmbLatihan_Inggris_Guru);
            panel2.Controls.Add(label3);
            panel2.Location = new Point(51, 507);
            panel2.Name = "panel2";
            panel2.Size = new Size(1149, 100);
            panel2.TabIndex = 29;
            // 
            // btnSoal_Inggris
            // 
            btnSoal_Inggris.BackColor = Color.FromArgb(0, 132, 130);
            btnSoal_Inggris.FlatAppearance.BorderSize = 0;
            btnSoal_Inggris.FlatStyle = FlatStyle.Flat;
            btnSoal_Inggris.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSoal_Inggris.ForeColor = Color.White;
            btnSoal_Inggris.Location = new Point(1020, 42);
            btnSoal_Inggris.Name = "btnSoal_Inggris";
            btnSoal_Inggris.Size = new Size(110, 31);
            btnSoal_Inggris.TabIndex = 3;
            btnSoal_Inggris.Text = "BUKA";
            btnSoal_Inggris.UseVisualStyleBackColor = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.document_7538078;
            pictureBox3.Location = new Point(3, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(100, 94);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // cmbLatihan_Inggris_Guru
            // 
            cmbLatihan_Inggris_Guru.FormattingEnabled = true;
            cmbLatihan_Inggris_Guru.Location = new Point(109, 50);
            cmbLatihan_Inggris_Guru.Name = "cmbLatihan_Inggris_Guru";
            cmbLatihan_Inggris_Guru.Size = new Size(309, 23);
            cmbLatihan_Inggris_Guru.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Schoolbook", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(109, 14);
            label3.Name = "label3";
            label3.Size = new Size(294, 23);
            label3.TabIndex = 1;
            label3.Text = "Latihan Soal Bahasa Inggris";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Schoolbook", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(71, 312);
            label1.Name = "label1";
            label1.Size = new Size(398, 55);
            label1.TabIndex = 34;
            label1.Text = "Bahasa Inggris";
            // 
            // Form_Inggris_Guru
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1251, 709);
            Controls.Add(label1);
            Controls.Add(btnEdit_Guru_Inggris);
            Controls.Add(btnKembali_Inggris_Guru);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(panel2);
            Name = "Form_Inggris_Guru";
            Text = "Form_Inggris_Guru";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnEdit_Guru_Inggris;
        private Button btnKembali_Inggris_Guru;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Button btnMateri_Inggris;
        private Label label2;
        private ComboBox cmbMateri_Inggris_Guru;
        private PictureBox pictureBox2;
        private Panel panel2;
        private Button btnSoal_Inggris;
        private PictureBox pictureBox3;
        private ComboBox cmbLatihan_Inggris_Guru;
        private Label label3;
        private Label label1;
    }
}