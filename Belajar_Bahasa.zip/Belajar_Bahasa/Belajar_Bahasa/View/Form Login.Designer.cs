﻿namespace Belajar_Bahasa.View
{
    partial class Form_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            LoginGuru = new Button();
            LoginMurid = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Desktop___1;
            pictureBox1.Location = new Point(-10, -7);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(999, 705);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(0, 132, 130);
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Bookman Old Style", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(100, 168);
            label1.Name = "label1";
            label1.Size = new Size(358, 56);
            label1.TabIndex = 2;
            label1.Text = "Selamat Datang di Aplikasi \r\nBelajar Bahasa\r\n";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(0, 132, 130);
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Bookman Old Style", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(68, 353);
            label2.Name = "label2";
            label2.Size = new Size(423, 24);
            label2.TabIndex = 2;
            label2.Text = "Mari kita mengingat siapakah kamu :)";
            // 
            // LoginGuru
            // 
            LoginGuru.BackColor = Color.FromArgb(15, 210, 217);
            LoginGuru.Cursor = Cursors.Hand;
            LoginGuru.FlatStyle = FlatStyle.Flat;
            LoginGuru.Font = new Font("Bookman Old Style", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LoginGuru.ForeColor = Color.Black;
            LoginGuru.Location = new Point(78, 401);
            LoginGuru.Name = "LoginGuru";
            LoginGuru.Size = new Size(110, 37);
            LoginGuru.TabIndex = 1;
            LoginGuru.Text = "Guru";
            LoginGuru.UseVisualStyleBackColor = false;
            LoginGuru.Click += LoginGuru_Click;
            // 
            // LoginMurid
            // 
            LoginMurid.BackColor = Color.FromArgb(15, 210, 217);
            LoginMurid.Cursor = Cursors.Hand;
            LoginMurid.FlatStyle = FlatStyle.Flat;
            LoginMurid.Font = new Font("Bookman Old Style", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LoginMurid.ForeColor = Color.Black;
            LoginMurid.Location = new Point(213, 401);
            LoginMurid.Name = "LoginMurid";
            LoginMurid.Size = new Size(110, 37);
            LoginMurid.TabIndex = 1;
            LoginMurid.Text = "Murid";
            LoginMurid.UseVisualStyleBackColor = false;
            LoginMurid.Click += LoginMurid_Click;
            // 
            // Form_Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoValidate = AutoValidate.Disable;
            ClientSize = new Size(984, 661);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(LoginMurid);
            Controls.Add(LoginGuru);
            Controls.Add(pictureBox1);
            Name = "Form_Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form_Dashboard";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private Label label2;
        private Button LoginGuru;
        private Button LoginMurid;
    }
}